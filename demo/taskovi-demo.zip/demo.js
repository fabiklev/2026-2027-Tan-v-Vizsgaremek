"use strict";

const paths = {
  logo: '<path fill="currentColor" stroke="none" d="M14 2 4 14h7l-1 8 10-12h-7z"/>',
  phone: '<rect x="6.5" y="2" width="11" height="20" rx="3"/><path d="M10 18h4"/>',
  monitor: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M12 17v4m-4 0h8"/>',
  reset: '<path d="M3 12a9 9 0 1 1 2.7 6.4M3 12V5m0 7h7"/>',
  "arrow-right": '<path d="M4 12h15m-6-6 6 6-6 6"/>',
  "arrow-left": '<path d="M20 12H5m6-6-6 6 6 6"/>',
  sync: '<path d="M4 9a8 8 0 0 1 13-4l3 3m0 0V3m0 5h-5M20 15a8 8 0 0 1-13 4l-3-3m0 0v5m0-5h5"/>',
  briefcase: '<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V4h8v3M3 12a23 23 0 0 0 18 0m-9 1v2"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.2"/><rect x="14" y="3" width="7" height="7" rx="1.2"/><rect x="3" y="14" width="7" height="7" rx="1.2"/><rect x="14" y="14" width="7" height="7" rx="1.2"/>',
  lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
  signal: '<path fill="currentColor" stroke="none" d="M3 15h3v5H3zm5-3h3v8H8zm5-4h3v12h-3zm5-4h3v16h-3z"/>',
  wifi: '<path d="M3 9a14 14 0 0 1 18 0m-15 4a9 9 0 0 1 12 0m-9 4a4 4 0 0 1 6 0"/><circle fill="currentColor" stroke="none" cx="12" cy="21" r="1.1"/>',
  battery: '<rect x="2" y="6" width="18" height="12" rx="2"/><path d="M22 10v4"/><rect x="4" y="8" width="14" height="8" rx="1" fill="currentColor" stroke="none"/>',
  search: '<circle cx="10.8" cy="10.8" r="6.6"/><path d="m16 16 4 4"/>',
  sliders: '<path d="M4 6h4m4 0h8M4 12h10m4 0h2M4 18h3m4 0h9m-12-2v4m8-10v4M10 4v4"/>',
  bookmark: '<path d="M6 5a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v15l-6-4-6 4z"/>',
  bell: '<path d="M18 8a6 6 0 1 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9m-8 12a2.2 2.2 0 0 0 4 0"/>',
  user: '<circle cx="12" cy="8" r="3.5"/><path d="M5 21v-2a4 4 0 0 1 4-4h6a4 4 0 0 1 4 4v2"/>',
  list: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 8h6m-6 4h6m-6 4h5"/>',
  message: '<path d="M20 11.5a7.8 7.8 0 0 1-8 7.5c-1.2 0-2.3-.2-3.3-.6L4 20l1.4-4.2A7 7 0 0 1 4 11.5 7.8 7.8 0 0 1 12 4a7.8 7.8 0 0 1 8 7.5z"/><path d="M8.5 11.5h7"/>',
  pin: '<path d="M19 10c0 5-7 10-7 10s-7-5-7-10a7 7 0 1 1 14 0z"/><circle cx="12" cy="10" r="2.1"/>',
  clock: '<circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4m8-4v4M3 10h18m-13 4h3m3 0h2m-8 3h3"/>',
  leaf: '<path d="M19.8 3.9c1 8.2-1 15-7.7 15-3.2 0-5.6-2.5-5.6-5.6 0-6.4 7.8-5.6 13.3-9.4zM4 21c3.8-5.7 7.9-9.7 12-12"/>',
  package: '<path d="m12 3 8 4.4v9.2L12 21l-8-4.4V7.4L12 3zM4 7.4l8 4.6 8-4.6m-8 4.6v9m-4-15.8 8 4.5"/>',
  users: '<circle cx="10" cy="8" r="3"/><path d="M4 20v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2m.5-14.8a3 3 0 0 1 0 5.6m2 3.5a3.7 3.7 0 0 1 2.5 3.6v2.1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  chevron: '<path d="m9 5 7 7-7 7"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  send: '<path d="m3 4 18 8-18 8 3.5-8L3 4zm3.5 8H21"/>',
  star: '<path d="m12 3 2.8 5.8 6.4.9-4.6 4.5 1.1 6.4-5.7-3-5.7 3 1.1-6.4L2.8 9.7l6.4-.9L12 3z"/>',
  x: '<path d="m6 6 12 12M18 6 6 18"/>'
};

function icon(name) {
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${paths[name] || ""}</svg>`;
}

function hydrateIcons(scope) {
  scope.querySelectorAll("[data-icon]:empty").forEach(node => {
    node.innerHTML = icon(node.dataset.icon);
  });
}

const categories = {
  all: { label: "Összes", icon: "briefcase" },
  kert: { label: "Kert", icon: "leaf" },
  esemeny: { label: "Esemény", icon: "calendar" },
  segitseg: { label: "Segítség", icon: "package" },
  online: { label: "Online", icon: "monitor" }
};
const roles = { worker: "Segítő", employer: "Megrendelő" };
const otherRole = { worker: "employer", employer: "worker" };
const storageKey = "taskovi-bemutato-v1";
const demoJob = "kert-01";
const chatKey = jobId => `${jobId}|worker`;
const moneyFormat = new Intl.NumberFormat("hu-HU");
const timeFormat = new Intl.DateTimeFormat("hu-HU", { hour: "2-digit", minute: "2-digit" });
const escapeMap = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
const h = value => String(value ?? "").replace(/[&<>"']/g, char => escapeMap[char]);
const money = value => `${moneyFormat.format(value)} Ft`;

function seed() {
  return {
    profiles: {
      worker: { name: "Farkas Nóri", city: "Esztergom", bio: "Rugalmas időbeosztásban vállalok alkalmi munkát. Kertészkedésben és rendezvényeken is szívesen segítek." },
      employer: { name: "Kovács Dóra", city: "Esztergom", bio: "Helyi feladatokhoz keresek segítőket Esztergomban és a környékén." }
    },
    jobs: [
      { id: demoJob, title: "Kerti segítség szombatra", category: "kert", location: "Esztergom", schedule: "Szombat, 10:00", pay: 12000, featured: true, status: "open", description: "Segítséget keresek avargyűjtéshez és a magaságyások rendbetételéhez. A feladat nagyjából 3 órás, a szerszámokat én adom." },
      { id: "rendezveny-02", title: "Segítség egy rendezvényen", category: "esemeny", location: "Dorog", schedule: "Vasárnap, 14:00", pay: 16000, status: "open", description: "Asztalok rendezése és vendégek fogadása egy helyi közösségi rendezvényen. A munka körülbelül 4 órát vesz igénybe." },
      { id: "doboz-03", title: "Dobozok pakolása", category: "segitseg", location: "Esztergom", schedule: "Hétfő, 16:00", pay: 9000, status: "open", description: "Néhány könnyebb dobozt kell átvinnünk a földszinti raktárba. Körülbelül 2 órára keresek segítséget." },
      { id: "foto-04", title: "Termékfotók válogatása", category: "online", location: "Otthonról", schedule: "Rugalmas", pay: 10000, status: "open", description: "Egy képmappából kell kiválasztani és elnevezni a webáruházba kerülő termékfotókat. A feladat otthonról végezhető." },
      { id: "plakat-05", title: "Plakátok kihelyezése", category: "esemeny", location: "Esztergom", schedule: "Múlt szombat", pay: 8000, status: "completed", description: "Plakátok kihelyezése a város kijelölt hirdetőtábláin." }
    ],
    applications: [
      { jobId: "rendezveny-02", worker: "sample", status: "pending", note: "Szia! Vasárnap ráérek, korábban is segítettem rendezvényen." },
      { jobId: "plakat-05", worker: "worker", status: "accepted", note: "Szia! Szombaton szívesen segítek." }
    ],
    saved: [],
    chats: {
      [chatKey("plakat-05")]: [
        { sender: "employer", text: "Szia Nóri! Köszönöm a segítséget a plakátokkal.", time: "16:42" },
        { sender: "worker", text: "Szívesen! Ha lesz hasonló, szólj nyugodtan.", time: "16:46" }
      ]
    },
    notices: {
      worker: [{ id: "n0", type: "job", title: "A munkád lezárult", detail: "Plakátok kihelyezése", jobId: "plakat-05", read: false }],
      employer: [{ id: "n1", type: "application", title: "Új jelentkezés", detail: "Kiss Vince · Segítség egy rendezvényen", jobId: "rendezveny-02", read: false }]
    },
    reviews: [
      { jobId: "plakat-05", from: "employer", to: "worker", rating: 5, text: "Nóri pontosan érkezett, és mindennel időben elkészült." }
    ]
  };
}

function readData() {
  try {
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed.profiles?.worker && parsed.profiles?.employer && Array.isArray(parsed.jobs) &&
          Array.isArray(parsed.applications) && Array.isArray(parsed.saved) && parsed.chats &&
          parsed.notices?.worker && parsed.notices?.employer && Array.isArray(parsed.reviews)) return parsed;
    }
  } catch {
    // The demo can run for this page load when browser storage is unavailable.
  }
  return seed();
}

function view(role) {
  return { role, page: role === "worker" ? "jobs" : "dashboard", jobId: null, query: "", category: "all", sort: "recent", filters: false, drafts: {} };
}

function initialViews() {
  return { worker: view("worker"), employer: view("employer"), web: view("worker") };
}

let data = readData();
let views = initialViews();
const panels = Object.fromEntries([...document.querySelectorAll("[data-panel]")].map(node => [node.dataset.panel, node]));

function userName(role) {
  return role === "sample" ? "Kiss Vince" : data.profiles[role].name;
}

function initials(name) {
  return name.trim().split(/\s+/).slice(0, 2).map(part => Array.from(part)[0]?.toLocaleUpperCase("hu-HU") || "").join("");
}

function avatar(role, name = userName(role)) {
  return `<span class="avatar ${role === "employer" ? "employer" : ""}" aria-hidden="true">${h(initials(name))}</span>`;
}

function appWordmark() {
  return `<span class="app-wordmark"><span class="brand-mark" data-icon="logo"></span><span>taskovi<span class="brand-period">.</span></span></span>`;
}

const workerTabs = [
  ["jobs", "search", "Munkák", "Munkák"],
  ["saved", "bookmark", "Mentett", "Mentett munkák"],
  ["applications", "list", "Jelentk.", "Jelentkezéseim"],
  ["messages", "message", "Üzenetek", "Üzenetek"],
  ["profile", "user", "Profil", "Profil"]
];
const employerTabs = [
  ["dashboard", "grid", "Kezdőlap", "Áttekintés"],
  ["listings", "briefcase", "Munkáim", "Hirdetéseim"],
  ["applications", "users", "Jelentkezők", "Jelentkezők"],
  ["messages", "message", "Üzenetek", "Üzenetek"],
  ["profile", "user", "Profil", "Profil"]
];

function navPage(v) {
  if (v.page === "detail" || v.page === "apply" || v.page === "review") return v.back || "jobs";
  if (v.page === "publish") return v.back || "listings";
  if (v.page === "chat") return "messages";
  if (v.page === "edit") return "profile";
  return v.page;
}

function appHeader(v) {
  const count = data.notices[v.role].filter(item => !item.read).length;
  const bellLabel = count ? `Értesítések, ${count} olvasatlan` : "Értesítések";
  return `<div class="app-header">${appWordmark()}<div class="app-tools">
    <button type="button" class="icon-button" data-action="nav" data-page="notifications" aria-label="${bellLabel}" title="Értesítések">${icon("bell")}${count ? '<span class="notification-dot" aria-hidden="true"></span>' : ""}</button>
    <button type="button" class="avatar-button" data-action="nav" data-page="profile" aria-label="Saját profil" title="Saját profil">${avatar(v.role)}</button>
  </div></div>`;
}

function appNav(v, web) {
  const tabs = v.role === "worker" ? workerTabs : employerTabs;
  const active = navPage(v);
  const unread = data.notices[v.role].some(item => item.type === "message" && !item.read);
  return `<nav class="app-nav" aria-label="${roles[v.role]} alkalmazásmenü">${tabs.map(([page, glyph, short, full]) => `
    <button class="tab-button" type="button" data-action="nav" data-page="${page}" ${full !== short ? `aria-label="${full}"` : ""} ${page === active ? 'aria-current="page"' : ""}>
      <span class="tab-icon">${icon(glyph)}${page === "messages" && unread ? '<span class="nav-dot" aria-label="Olvasatlan üzenet"></span>' : ""}</span>
      ${web && full !== short ? `<span class="tab-long">${full}</span><span class="tab-short" aria-hidden="true">${short}</span>` : `<span>${web ? full : short}</span>`}
    </button>`).join("")}</nav>`;
}

function heading(title, caption = "") {
  return `<div class="app-heading"><h2 data-page-heading tabindex="-1">${h(title)}</h2>${caption ? `<p>${h(caption)}</p>` : ""}</div>`;
}

function sectionLabel(title, right = "") {
  return `<div class="section-label"><h3>${h(title)}</h3>${right ? `<span>${h(right)}</span>` : ""}</div>`;
}

function empty(glyph, title, detail) {
  return `<div class="empty"><span data-icon="${glyph}"></span><strong>${h(title)}</strong><p>${h(detail)}</p></div>`;
}

function btn(label, action, glyph = "", options = {}) {
  const { kind = "primary", full = false, jobId = "", value = "", disabled = false } = options;
  return `<button class="button ${kind}${full ? " full" : ""}" type="button" data-action="${action}" ${jobId ? `data-job="${h(jobId)}"` : ""} ${value ? `data-value="${h(value)}"` : ""} ${disabled ? "disabled" : ""}>${glyph ? icon(glyph) : ""}${h(label)}</button>`;
}

function backButton() {
  return btn("Vissza", "back", "arrow-left", { kind: "quiet" });
}

function badge(status) {
  const labels = {
    open: ["Nyitott", "green"],
    assigned: ["Folyamatban", "green"],
    completed: ["Befejezve", "gray"],
    pending: ["Elbírálás alatt", ""],
    accepted: ["Elfogadva", "green"],
    declined: ["Elutasítva", "gray"],
    withdrawn: ["Visszavonva", "gray"]
  };
  const [text, color] = labels[status] || labels.open;
  return `<span class="badge ${color}">${text}</span>`;
}

function jobPhoto(job, detail = false) {
  if (!job.featured) return "";
  return `<span class="job-photo${detail ? " detail-photo" : ""}">
    <img src="./assets/kert.webp" alt="" width="960" height="640">
    ${detail ? "" : '<span class="job-tag">Kiemelt munka</span>'}
  </span>`;
}

function jobMeta(job) {
  return `<span class="job-meta"><span>${icon("pin")}${h(job.location)}</span><span>${icon("clock")}${h(job.schedule)}</span></span>`;
}

function jobCard(job) {
  const saved = data.saved.includes(job.id);
  return `<article class="job-card${job.featured ? " feature" : ""}">
    <button class="job-link" type="button" data-action="detail" data-job="${h(job.id)}">
      ${jobPhoto(job)}
      ${job.featured ? "" : `<span class="job-symbol ${job.category}">${icon(categories[job.category].icon)}</span>`}
      <span class="job-body">
        <strong>${h(job.title)}</strong><span class="job-price">${money(job.pay)}</span>${jobMeta(job)}
      </span>
    </button>
    <button type="button" class="save-job" data-action="save" data-job="${h(job.id)}" aria-label="${saved ? "Eltávolítás a mentett munkákból" : "Munka mentése"}" aria-pressed="${saved}" title="${saved ? "Mentés törlése" : "Mentés"}">${icon("bookmark")}</button>
  </article>`;
}

function normalize(text) {
  return text.toLocaleLowerCase("hu-HU").normalize("NFD").replace(/\p{Diacritic}/gu, "");
}

function filteredJobs(v) {
  const terms = normalize(v.query.trim()).split(/\s+/).filter(Boolean);
  const result = data.jobs.filter(job => job.status === "open" &&
    (v.category === "all" || v.category === job.category) &&
    terms.every(term => normalize(`${job.title} ${job.location} ${job.description} ${categories[job.category].label}`).includes(term)));
  if (v.sort === "pay") result.sort((a, b) => b.pay - a.pay);
  return result;
}

function jobsResults(v) {
  const jobs = filteredJobs(v);
  const filtered = Boolean(v.query.trim() || v.category !== "all");
  return `${sectionLabel(filtered ? "Találatok" : "Friss munkák", `${jobs.length} ${filtered ? "találat" : "munka"}`)}
    ${jobs.length ? `<div class="job-list">${jobs.map(jobCard).join("")}</div>` : empty("search", "Nincs találat", "Próbálj másik keresőkifejezést vagy kategóriát.")}`;
}

function renderJobs(v, web) {
  const search = `<form class="search-form" data-form="search" role="search">
    <label class="search-field">${icon("search")}<span class="visually-hidden">Keresés a munkák között</span><input name="query" type="search" value="${h(v.query)}" placeholder="Munka vagy helyszín…" autocomplete="off"></label>
    <button type="button" class="icon-button" data-action="filters" aria-label="Rendezési lehetőségek" title="Rendezés" aria-expanded="${v.filters}">${icon("sliders")}</button>
  </form>
  ${v.filters ? `<div class="form"><label>Rendezés<select name="sort" data-sort><option value="recent" ${v.sort === "recent" ? "selected" : ""}>Legfrissebb elöl</option><option value="pay" ${v.sort === "pay" ? "selected" : ""}>Legmagasabb díj elöl</option></select></label></div>` : ""}
  <div class="chips" role="group" aria-label="Munkakategóriák">${Object.entries(categories).map(([key, category]) => `<button class="chip" type="button" data-action="category" data-value="${key}" aria-pressed="${v.category === key}">${category.label}</button>`).join("")}</div>
  <section data-jobs-results aria-live="polite">${jobsResults(v)}</section>`;
  if (!web) return `${heading("Találj munkát", "Alkalmi lehetőségek a közeledben.")}${search}`;
  return `${heading("Találj munkát", "Alkalmi lehetőségek a közeledben.")}
    <div class="app-columns"><div class="app-page">${search}</div><aside class="aside">
    <div class="detail-block"><h3>A munkáid</h3>
      <p class="muted">${data.saved.length} mentett munka · ${data.applications.filter(app => app.worker === "worker" && app.status === "pending").length} függő jelentkezés</p></div>
    ${btn("Mentett munkák", "go-saved", "bookmark", { kind: "secondary" })}
  </aside></div>`;
}

function renderSaved() {
  const jobs = data.jobs.filter(job => data.saved.includes(job.id));
  return `${heading("Mentett munkák", "Az elmentett hirdetéseid egy helyen.")}
    ${jobs.length ? `<div class="job-list">${jobs.map(jobCard).join("")}</div>` : empty("bookmark", "Még nincs mentett munkád", "A hirdetés könyvjelző ikonjával menthetsz egy munkát.")}`;
}

function row({ title, detail, glyph, action, jobId, value, mark, unread = false, person }) {
  const inside = `${person ? avatar(person) : `<span class="row-icon">${icon(glyph)}</span>`}
    <span class="row-copy"><strong>${h(title)}</strong><small>${h(detail)}</small></span>
    ${mark || ""}${unread ? '<span class="row-unread" aria-label="Olvasatlan"></span>' : ""}
    ${action ? `<span class="chevron">${icon("chevron")}</span>` : ""}`;
  if (!action) return `<div class="app-row">${inside}</div>`;
  return `<button class="app-row" type="button" data-action="${action}" ${jobId ? `data-job="${h(jobId)}"` : ""} ${value ? `data-value="${h(value)}"` : ""}>${inside}</button>`;
}

function applicationsFor(jobId) {
  return data.applications.filter(app => app.jobId === jobId);
}

function listingRow(job) {
  return row({
    title: job.title,
    detail: `${job.location} · ${applicationsFor(job.id).filter(app => app.status !== "withdrawn").length} jelentkező`,
    glyph: categories[job.category].icon, action: "detail", jobId: job.id, mark: badge(job.status)
  });
}

function renderDashboard(web) {
  const active = data.jobs.filter(job => job.status !== "completed");
  const pending = data.applications.filter(app => app.status === "pending").length;
  const latest = data.notices.employer[0];
  const listings = `<section>${sectionLabel("Saját hirdetések")}
    <div class="list-stack">${active.slice(0, 2).map(listingRow).join("") || empty("briefcase", "Nincs aktív hirdetés", "Adj fel egy új hirdetést a kezdéshez.")}</div>
    ${btn("Összes hirdetés", "go-listings", "arrow-right", { kind: "quiet" })}
  </section>`;
  const activity = `<section class="${web ? "aside" : ""}">${sectionLabel("Friss aktivitás")}
    ${latest ? noticeRow(latest) : empty("bell", "Nincs friss aktivitás", "Itt jelennek meg az új események.")}
  </section>`;
  return `${heading(`Szia, ${data.profiles.employer.name.split(/\s+/).at(-1)}!`, "Itt kezelheted a hirdetéseidet és a jelentkezőket.")}
  <div class="stats">
    <button type="button" class="stat" data-action="go-listings"><span>Aktív hirdetés</span><span class="stat-icon">${icon("briefcase")}</span><strong>${active.length}</strong></button>
    <button type="button" class="stat" data-action="go-applications"><span>Függő jelentkezés</span><span class="stat-icon">${icon("users")}</span><strong>${pending}</strong></button>
  </div>
  <div class="action-row">${btn("Új hirdetés", "publish", "plus", { full: !web })}</div>
  ${web ? `<div class="app-columns">${listings}${activity}</div>` : listings + activity}`;
}

function renderListings() {
  return `${heading("Hirdetéseim", "A feladott munkáid és azok állapota.")}
    <div class="action-row">${btn("Új hirdetés", "publish", "plus")}</div>
    <div class="list-stack">${data.jobs.map(listingRow).join("")}</div>`;
}

function renderApplications(v) {
  const worker = v.role === "worker";
  const applications = worker ? data.applications.filter(app => app.worker === "worker") : data.applications.filter(app => app.status !== "withdrawn");
  const ordered = [...applications].sort((a, b) => Number(b.status === "pending") - Number(a.status === "pending"));
  const rows = ordered.map(app => {
    const job = data.jobs.find(item => item.id === app.jobId);
    return row({
      title: worker ? job.title : userName(app.worker), detail: worker ? job.location : job.title,
      glyph: "list", action: "detail", jobId: app.jobId, person: worker ? "" : app.worker,
      mark: badge(job.status === "completed" && app.status === "accepted" ? "completed" : app.status)
    });
  });
  return `${heading(worker ? "Jelentkezéseim" : "Jelentkezők", worker ? "Kövesd a jelentkezéseid állapotát." : "A hirdetéseidre beérkezett jelentkezések.")}
    ${rows.length ? `<div class="list-stack">${rows.join("")}</div>` : empty("list", "Még nincs jelentkezés", worker ? "Válassz ki egy munkát, és jelentkezz rá." : "Az új jelentkezők itt jelennek meg.")}`;
}

function renderWorkerDetail(job, app) {
  const actions = [];
  if (job.status === "open" && (!app || app.status === "withdrawn")) actions.push(btn("Jelentkezem", "apply", "arrow-right", { jobId: job.id }));
  if (app?.status === "pending") actions.push(btn("Jelentkezés visszavonása", "withdraw", "x", { kind: "secondary", jobId: job.id }));
  if (app && (app.status === "pending" || app.status === "accepted")) actions.push(btn("Üzenet a megrendelőnek", "chat", "message", { kind: "secondary", jobId: job.id }));
  if (app?.status === "accepted" && job.status === "completed") actions.push(reviewAction(job, "worker"));
  const saved = data.saved.includes(job.id);
  actions.push(btn(saved ? "Mentés törlése" : "Munka mentése", "save", "bookmark", { kind: "secondary", jobId: job.id }));
  return `<div class="detail-block">
    ${app ? badge(job.status === "completed" && app.status === "accepted" ? "completed" : app.status) : ""}
    <div class="action-row">${actions.join("")}</div>
    <div class="profile-card">${avatar("employer")}<div><h3>${h(userName("employer"))}</h3><p class="muted">Megrendelő</p></div></div>
  </div>`;
}

function reviewAction(job, role) {
  const exists = data.reviews.some(review => review.jobId === job.id && review.from === role);
  return exists ? `<span class="badge green">Értékelés elküldve</span>` : btn("Értékelés írása", "review", "star", { jobId: job.id });
}

function employerApplicant(job, app) {
  const canChoose = job.status === "open" && app.status === "pending";
  return `<div class="application">
    ${row({ title: userName(app.worker), detail: "Jelentkező", person: app.worker, mark: badge(app.status) })}
    ${app.note ? `<p class="description">${h(app.note)}</p>` : ""}
    <div class="action-row">
      ${canChoose ? btn("Elfogadás", "accept", "check", { jobId: job.id, value: app.worker }) + btn("Elutasítás", "decline", "", { kind: "secondary", jobId: job.id, value: app.worker }) : ""}
      ${app.worker === "worker" && (app.status === "accepted" || app.status === "pending") ? btn("Üzenet", "chat", "message", { kind: "secondary", jobId: job.id }) : ""}
      ${app.status === "accepted" && job.status === "assigned" ? btn("Munka lezárása", "complete", "check", { jobId: job.id }) : ""}
      ${app.status === "accepted" && app.worker === "worker" && job.status === "completed" ? reviewAction(job, "employer") : ""}
    </div>
  </div>`;
}

function renderDetail(v) {
  const job = data.jobs.find(item => item.id === v.jobId);
  if (!job) return `${backButton()}${empty("briefcase", "A munka nem érhető el", "Válassz egy másik hirdetést.")}`;
  const applicants = applicationsFor(job.id).filter(app => app.status !== "withdrawn");
  const app = applicants.find(item => item.worker === "worker");
  return `${backButton()}${heading(job.title, categories[job.category].label)}
    ${jobPhoto(job, true)}
    <div class="detail-banner">${badge(job.status)}<strong class="job-price">${money(job.pay)}</strong>${jobMeta(job)}</div>
    <section class="detail-block"><h3>A feladat</h3><p class="description">${h(job.description)}</p></section>
    ${v.role === "worker" ? renderWorkerDetail(job, app) : `<section class="detail-block"><h3>Jelentkezők (${applicants.length})</h3>${applicants.map(item => employerApplicant(job, item)).join("") || empty("users", "Még nincs jelentkező", "A segítői nézetben kipróbálhatod a jelentkezést.")}</section>`}`;
}

function noticeRow(item) {
  const glyph = { application: "users", message: "message", job: "briefcase", review: "star" }[item.type] || "bell";
  return row({ title: item.title, detail: item.detail, glyph, action: "notice", value: item.id, unread: !item.read });
}

function renderNotifications(v) {
  const notices = data.notices[v.role];
  const unread = notices.some(item => !item.read);
  return `${heading("Értesítések", "Jelentkezések, üzenetek és állapotváltozások.")}
    ${unread ? btn("Összes megjelölése olvasottként", "read-all", "check", { kind: "secondary" }) : ""}
    ${notices.length ? `<div class="list-stack">${notices.map(noticeRow).join("")}</div>` : empty("bell", "Nincsenek értesítéseid", "Az új események itt jelennek meg.")}`;
}

function renderMessages(v) {
  const rows = Object.entries(data.chats).filter(([, messages]) => messages.length).reverse().map(([key, messages]) => {
    const job = data.jobs.find(item => chatKey(item.id) === key);
    const unread = data.notices[v.role].some(item => !item.read && item.jobId === job.id && item.type === "message");
    return row({ title: userName(otherRole[v.role]), detail: `${job.title} · ${messages.at(-1).text}`, person: otherRole[v.role], action: "chat", jobId: job.id, unread });
  });
  return `${heading("Üzenetek", "Egyeztess a munkához kapcsolódó beszélgetésekben.")}
    ${rows.length ? `<div class="list-stack">${rows.join("")}</div>` : empty("message", "Még nincs beszélgetés", "Nyiss meg egy jelentkezést az üzenetküldéshez.")}`;
}

function renderChat(v) {
  const job = data.jobs.find(item => item.id === v.jobId);
  const messages = data.chats[chatKey(job.id)] || [];
  return `${backButton()}${heading(userName(otherRole[v.role]), job.title)}
    <div class="chat-history" data-chat-history aria-label="Beszélgetés" role="log" aria-live="polite">
      ${messages.map(message => `<div class="chat-bubble${message.sender === v.role ? " mine" : ""}">${h(message.text)}<small>${h(message.time)}</small></div>`).join("") || '<p class="muted">Küldd el az első üzenetet.</p>'}
    </div>
    <form class="composer" data-form="chat"><label class="visually-hidden" for="message-${v.panel}">Üzenet szövege</label><input id="message-${v.panel}" name="message" maxlength="350" required autocomplete="off" placeholder="Írj üzenetet…">
      <button class="button primary" type="submit" aria-label="Üzenet küldése">${icon("send")}</button>
    </form>`;
}

function renderProfile(v) {
  const profile = data.profiles[v.role];
  const reviews = data.reviews.filter(review => review.to === v.role);
  return `${heading("Profilom", "A demóban használt adataid.")}
    <div class="profile-card">${avatar(v.role)}<div><h3>${h(profile.name)}</h3><p class="muted">${h(profile.city)} · ${roles[v.role]}</p></div></div>
    <p class="description">${h(profile.bio)}</p>
    <div class="action-row">${btn("Profil szerkesztése", "edit", "user", { kind: "secondary" })}</div>
    <section class="detail-block"><h3>Kapott értékelések (${reviews.length})</h3>
      ${reviews.length ? `<div class="reviews">${reviews.map(review => `<article class="review"><strong aria-label="${review.rating} az 5 csillagból">${"★".repeat(review.rating)}${"☆".repeat(5 - review.rating)}</strong><p class="description">${h(review.text)}</p><small class="muted">${h(userName(review.from))}</small></article>`).join("")}</div>` : empty("star", "Még nincs értékelés", "A lezárt munkák után adott értékelések itt jelennek meg.")}
    </section>`;
}

function renderForm(v) {
  const job = data.jobs.find(item => item.id === v.jobId);
  const profile = data.profiles[v.role];
  if (v.page === "publish") {
    return `${backButton()}${heading("Új hirdetés", "A hirdetés megjelenik a segítői nézetben.")}
      <form class="form" data-form="publish">
        <label>Munka címe<input name="title" maxlength="65" required placeholder="Pl. Könyvek rendezése"></label>
        <div class="form-group"><label>Kategória<select name="category">${Object.entries(categories).filter(([key]) => key !== "all").map(([key, cat]) => `<option value="${key}">${cat.label}</option>`).join("")}</select></label>
        <label>Díjazás (Ft)<input name="pay" type="number" min="100" max="1000000" step="1" required placeholder="12000"></label></div>
        <div class="form-group"><label>Helyszín<input name="location" maxlength="40" required placeholder="Esztergom"></label><label>Időpont<input name="schedule" maxlength="40" required placeholder="Szombat, 10:00"></label></div>
        <label>Feladat leírása<textarea name="description" maxlength="400" required placeholder="Mihez keresel segítséget?"></textarea></label>
        <div class="action-row"><button type="submit" class="button primary">${icon("plus")}Hirdetés feladása</button>${btn("Minta kitöltése", "fill", "", { kind: "secondary" })}</div>
      </form>`;
  }
  if (v.page === "edit") {
    return `${backButton()}${heading("Profil szerkesztése")}
      <form class="form" data-form="edit">
        <label>Név<input name="name" value="${h(profile.name)}" maxlength="45" required></label>
        <label>Település<input name="city" value="${h(profile.city)}" maxlength="40" required></label>
        <label>Bemutatkozás<textarea name="bio" maxlength="240">${h(profile.bio)}</textarea></label>
        <div class="action-row"><button type="submit" class="button primary">${icon("check")}Mentés</button></div>
      </form>`;
  }
  if (v.page === "review") {
    return `${backButton()}${heading("Értékelés írása", job.title)}
      <form class="form" data-form="review">
        <label>Értékelés<select name="rating"><option value="5">5 – Kiváló</option><option value="4">4 – Jó</option><option value="3">3 – Megfelelő</option><option value="2">2 – Gyenge</option><option value="1">1 – Rossz</option></select></label>
        <label>Visszajelzés<textarea name="text" maxlength="240" required placeholder="Hogyan ment a közös munka?"></textarea></label>
        <div class="action-row"><button type="submit" class="button primary">${icon("star")}Értékelés elküldése</button></div>
      </form>`;
  }
  return `${backButton()}${heading("Jelentkezés", job.title)}
    <form class="form" data-form="apply">
      <label>Bemutatkozó üzenet (opcionális)<textarea name="note" maxlength="300" placeholder="Szia! Szívesen segítek, szombaton ráérek."></textarea></label>
      <button type="submit" class="button primary">${icon("send")}Jelentkezés elküldése</button>
    </form>`;
}

function pageContent(v, web) {
  switch (v.page) {
    case "dashboard": return renderDashboard(web);
    case "listings": return renderListings();
    case "saved": return renderSaved();
    case "applications": return renderApplications(v);
    case "messages": return renderMessages(v);
    case "notifications": return renderNotifications(v);
    case "profile": return renderProfile(v);
    case "detail": return renderDetail(v);
    case "chat": return renderChat(v);
    case "apply":
    case "publish":
    case "review":
    case "edit": return renderForm(v);
    default: return renderJobs(v, web);
  }
}

function controlSnapshot(panel) {
  const active = document.activeElement;
  if (!panel.contains(active)) return null;
  if (active.name) {
    return {
      match: candidate => candidate.name === active.name && candidate.form?.dataset.form === active.form?.dataset.form,
      start: active.selectionStart,
      end: active.selectionEnd
    };
  }
  const keys = ["action", "page", "job", "value"];
  return {
    match: candidate => candidate.tagName === active.tagName && candidate.className === active.className &&
      keys.every(key => candidate.dataset[key] === active.dataset[key])
  };
}

function draftKey(v, form) {
  return `${form}:${v.jobId || ""}`;
}

function restoreDrafts(panel, v) {
  const form = panel.querySelector("form[data-form]");
  if (!form || form.dataset.form === "search") return;
  const saved = v.drafts[draftKey(v, form.dataset.form)];
  if (!saved) return;
  for (const [name, value] of Object.entries(saved)) {
    const field = form.elements.namedItem(name);
    if (field) field.value = value;
  }
}

function renderPanel(id, { pageFocus = false, formFocus = "", top = false } = {}) {
  const panel = panels[id];
  const v = views[id];
  const web = id === "web";
  const previous = controlSnapshot(panel);
  const scroll = panel.querySelector(".app-main")?.scrollTop || 0;
  const main = `<div class="app-main"><div class="app-page">${pageContent({ ...v, panel: id }, web)}</div></div>`;
  const nav = appNav(v, web);
  panel.dataset.role = v.role;
  panel.innerHTML = appHeader(v) + (web ? nav + main : main + nav);
  hydrateIcons(panel);
  restoreDrafts(panel, v);
  panel.querySelector(".app-main").scrollTop = top ? 0 : scroll;

  if (pageFocus) {
    const heading = panel.querySelector("[data-page-heading]");
    heading?.focus({ preventScroll: true });
    if (web && heading && heading.getBoundingClientRect().top < 85) {
      document.querySelector("#bongeszo").scrollIntoView({ block: "start" });
    }
    return;
  }
  if (formFocus) {
    panel.querySelector(`[name="${formFocus}"]`)?.focus({ preventScroll: true });
    return;
  }
  if (previous) {
    const target = [...panel.querySelectorAll("button, input, textarea, select, [tabindex]")].find(previous.match);
    target?.focus({ preventScroll: true });
    if (previous.start != null && target?.setSelectionRange) target.setSelectionRange(previous.start, previous.end);
  }
}

function renderAll(active = "", options = {}) {
  for (const id of Object.keys(panels)) renderPanel(id, id === active ? options : {});
  document.querySelectorAll("[data-action='web-role']").forEach(button => {
    button.setAttribute("aria-pressed", String(button.dataset.role === views.web.role));
  });
}

let toastTimeout;
function toast(message) {
  const element = document.querySelector(".toast");
  clearTimeout(toastTimeout);
  element.textContent = message;
  element.classList.add("visible");
  toastTimeout = setTimeout(() => {
    element.classList.remove("visible");
    element.textContent = "";
  }, 3200);
}

function persist(active, message, options) {
  try {
    localStorage.setItem(storageKey, JSON.stringify(data));
  } catch {
    // Keep the live demo usable for browsers that decline local storage.
  }
  renderAll(active, options);
  if (message) toast(message);
}

function idFor(prefix) {
  return `${prefix}-${globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`}`;
}

function notify(role, type, title, detail, jobId, worker) {
  if (role === "sample") return;
  data.notices[role].unshift({ id: idFor("n"), type, title, detail, jobId, read: false, worker });
  data.notices[role] = data.notices[role].slice(0, 50);
}

function startPage(v) {
  return v.role === "worker" ? "jobs" : "dashboard";
}

function changePage(id, page) {
  const v = views[id];
  v.page = page;
  v.jobId = null;
  v.back = "";
  v.chatBack = "";
  v.drafts = {};
  renderPanel(id, { top: true, pageFocus: true });
}

function openDetail(id, jobId, from) {
  const v = views[id];
  v.back = from || navPage(v);
  v.jobId = jobId;
  v.page = "detail";
  renderPanel(id, { top: true, pageFocus: true });
}

function goBack(id) {
  const v = views[id];
  if (v.page === "apply" || v.page === "review") {
    v.page = "detail";
  } else if (v.page === "chat" && v.chatBack === "detail") {
    v.page = "detail";
  } else {
    const target = v.page === "chat" ? v.chatBack : v.page === "edit" ? "profile" : v.back;
    changePage(id, target || startPage(v));
    return;
  }
  renderPanel(id, { top: true, pageFocus: true });
}

function openForm(id, page) {
  const v = views[id];
  if (page === "publish") v.back = navPage(v);
  v.page = page;
  renderPanel(id, { top: true, pageFocus: true });
}

function updateResults(id) {
  const results = panels[id].querySelector("[data-jobs-results]");
  if (!results) return;
  results.innerHTML = jobsResults(views[id]);
  hydrateIcons(results);
}

function moveToChat(v, jobId, from) {
  const app = applicationsFor(jobId).find(item => item.worker === "worker");
  if (!app || !["pending", "accepted"].includes(app.status)) {
    if (!data.chats[chatKey(jobId)]?.length) return false;
  }
  v.chatBack = from === "chat" ? v.chatBack : from;
  v.jobId = jobId;
  v.page = "chat";
  for (const item of data.notices[v.role]) {
    if (item.type === "message" && item.jobId === jobId) item.read = true;
  }
  return true;
}

function viewNotice(id, noticeId) {
  const v = views[id];
  const item = data.notices[v.role].find(entry => entry.id === noticeId);
  if (!item) return;
  item.read = true;
  if (item.type === "message" && moveToChat(v, item.jobId, v.page)) {
    persist(id, "", { top: true, pageFocus: true });
    return;
  }
  v.back = v.page;
  v.jobId = item.jobId;
  v.page = "detail";
  persist(id, "", { top: true, pageFocus: true });
}

function decideApplication(id, job, worker, accepted) {
  if (!job || job.status !== "open") return;
  const chosen = applicationsFor(job.id).find(app => app.worker === worker && app.status === "pending");
  if (!chosen) return;
  chosen.status = accepted ? "accepted" : "declined";
  notify(worker, "job", accepted ? "Elfogadták a jelentkezésed" : "Elutasították a jelentkezésed", job.title, job.id);
  if (accepted) {
    job.status = "assigned";
    for (const app of applicationsFor(job.id)) {
      if (app.status !== "pending") continue;
      app.status = "declined";
      notify(app.worker, "job", "A megrendelő kiválasztott egy segítőt", job.title, job.id);
    }
  }
  persist(id, accepted ? "A jelentkezést elfogadtad." : "A jelentkezést elutasítottad.");
}

function setSaved(id, job) {
  if (!job) return;
  const alreadySaved = data.saved.includes(job.id);
  data.saved = alreadySaved ? data.saved.filter(key => key !== job.id) : [...data.saved, job.id];
  persist(id, alreadySaved ? "A mentést törölted." : "A munkát elmentetted.");
}

function fillDemo(id) {
  const values = {
    title: "Könyvek rendezése",
    category: "segitseg",
    pay: "11000",
    location: "Esztergom",
    schedule: "Kedd, 15:00",
    description: "Segítséget keresek egy kisebb könyvgyűjtemény rendszerezéséhez. A feladat körülbelül két órát vesz igénybe."
  };
  const v = views[id];
  v.drafts[draftKey(v, "publish")] = values;
  restoreDrafts(panels[id], v);
  panels[id].querySelector('[name="title"]')?.focus({ preventScroll: true });
}

const resetDialog = document.querySelector("#reset-dialog");
resetDialog.addEventListener("close", () => {
  if (resetDialog.returnValue !== "reset") return;
  data = seed();
  views = initialViews();
  persist("", "A demó visszaállt a kezdeti állapotra.");
  for (const panel of Object.values(panels)) panel.querySelector(".app-main").scrollTop = 0;
});

document.addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const { action, page, job: jobId, value, role } = button.dataset;
  const id = button.closest("[data-panel]")?.dataset.panel;
  if (action === "start") {
    openDetail("worker", demoJob, "jobs");
    document.querySelector(".worker-device").scrollIntoView({ block: "nearest" });
    return;
  }
  if (action === "reset-open") {
    resetDialog.returnValue = "";
    resetDialog.showModal();
    return;
  }
  if (action === "web-role") {
    if (views.web.role !== role) {
      views.web = view(role);
      renderAll("web");
    }
    return;
  }
  if (!id) return;
  const v = views[id];
  const job = data.jobs.find(item => item.id === (jobId || v.jobId));
  switch (action) {
    case "nav": changePage(id, page); break;
    case "go-saved": changePage(id, "saved"); break;
    case "go-listings": changePage(id, "listings"); break;
    case "go-applications": changePage(id, "applications"); break;
    case "detail": openDetail(id, jobId); break;
    case "back": goBack(id); break;
    case "filters":
      v.filters = !v.filters;
      renderPanel(id);
      break;
    case "category":
      v.category = value;
      panels[id].querySelectorAll('[data-action="category"]').forEach(chip => {
        chip.setAttribute("aria-pressed", String(chip.dataset.value === value));
      });
      updateResults(id);
      break;
    case "save": setSaved(id, job); break;
    case "publish":
    case "apply":
    case "edit":
    case "review": openForm(id, action); break;
    case "fill": fillDemo(id); break;
    case "notice": viewNotice(id, value); break;
    case "read-all":
      data.notices[v.role].forEach(item => { item.read = true; });
      persist(id, "Az értesítéseket olvasottnak jelölted.");
      break;
    case "chat":
      if (moveToChat(v, jobId, v.page)) persist(id, "", { top: true, pageFocus: true });
      break;
    case "accept":
    case "decline":
      decideApplication(id, job, value, action === "accept");
      break;
    case "withdraw": {
      const app = applicationsFor(jobId).find(item => item.worker === "worker" && item.status === "pending");
      if (!app) return;
      app.status = "withdrawn";
      data.notices.employer = data.notices.employer.filter(item => item.jobId !== job.id || item.type !== "application" || item.worker !== "worker");
      notify("employer", "job", "Jelentkezés visszavonva", `${userName("worker")} · ${job.title}`, job.id);
      persist(id, "Visszavontad a jelentkezést.");
      break;
    }
    case "complete": {
      if (!job || job.status !== "assigned") return;
      const accepted = applicationsFor(job.id).find(app => app.status === "accepted");
      if (!accepted) return;
      job.status = "completed";
      notify(accepted.worker, "job", "A munkád lezárult", job.title, job.id);
      persist(id, "A munkát lezártad.");
      break;
    }
  }
});

function onFieldChange(event) {
  const field = event.target;
  const form = field.closest("form[data-form]");
  const id = field.closest("[data-panel]")?.dataset.panel;
  if (!id) return;
  const v = views[id];
  if (field.matches("[data-sort]")) {
    v.sort = field.value;
    updateResults(id);
    return;
  }
  if (!form) return;
  if (form.dataset.form === "search") {
    v.query = field.value;
    updateResults(id);
    return;
  }
  field.setCustomValidity?.("");
  const key = draftKey(v, form.dataset.form);
  v.drafts[key] = Object.fromEntries(new FormData(form));
}

document.addEventListener("input", onFieldChange);
document.addEventListener("change", event => {
  if (event.target.matches("select")) onFieldChange(event);
});

function requiredText(form, values, names) {
  for (const name of names) {
    if (values[name]) continue;
    const input = form.elements.namedItem(name);
    input.setCustomValidity("Töltsd ki ezt a mezőt.");
    input.reportValidity();
    return false;
  }
  return true;
}

function publishJob(id, v, form, values) {
  if (!requiredText(form, values, ["title", "location", "schedule", "description"])) return;
  const job = {
    id: idFor("munka"), title: values.title, category: values.category, location: values.location,
    schedule: values.schedule, pay: Number(values.pay), status: "open", description: values.description
  };
  data.jobs.unshift(job);
  v.drafts = {};
  v.jobId = job.id;
  v.back = "listings";
  v.page = "detail";
  persist(id, "A hirdetés megjelent a segítői nézetben.", { top: true, pageFocus: true });
}

function applyForJob(id, v, job, note) {
  const existing = applicationsFor(job.id).find(item => item.worker === "worker");
  if (job.status !== "open" || (existing && existing.status !== "withdrawn")) {
    v.page = "detail";
    renderPanel(id, { top: true, pageFocus: true });
    toast("Ehhez a munkához már nem küldhetsz új jelentkezést.");
    return;
  }
  if (existing) {
    existing.status = "pending";
    existing.note = note;
  } else {
    data.applications.unshift({ jobId: job.id, worker: "worker", status: "pending", note });
  }
  notify("employer", "application", "Új jelentkezés", `${userName("worker")} · ${job.title}`, job.id, "worker");
  v.drafts = {};
  v.page = "detail";
  v.back = "applications";
  persist(id, "A megrendelő megkapta a jelentkezésed.", { top: true, pageFocus: true });
}

function sendChat(id, v, job, form, text) {
  if (!requiredText(form, { message: text }, ["message"])) return;
  const app = applicationsFor(job.id).find(item => item.worker === "worker");
  if (!app || !["pending", "accepted"].includes(app.status)) {
    toast("Ehhez a jelentkezéshez jelenleg nem küldhető új üzenet.");
    return;
  }
  const key = chatKey(job.id);
  data.chats[key] ||= [];
  data.chats[key].push({ sender: v.role, text, time: timeFormat.format(new Date()) });
  notify(otherRole[v.role], "message", "Új üzenet", `${userName(v.role)} · ${job.title}`, job.id);
  delete v.drafts[draftKey(v, "chat")];
  persist(id, "", { formFocus: "message" });
  const area = panels[id].querySelector(".app-main");
  if (id !== "web") area.scrollTop = area.scrollHeight;
}

document.addEventListener("submit", event => {
  const form = event.target.closest("form[data-form]");
  const id = form?.closest("[data-panel]")?.dataset.panel;
  if (!id) return;
  event.preventDefault();
  const v = views[id];
  const job = data.jobs.find(item => item.id === v.jobId);
  const values = Object.fromEntries([...new FormData(form)].map(([key, value]) => [key, value.trim()]));
  switch (form.dataset.form) {
    case "search":
      v.query = values.query;
      updateResults(id);
      break;
    case "publish":
      publishJob(id, v, form, values);
      break;
    case "apply":
      if (job) applyForJob(id, v, job, values.note);
      break;
    case "edit":
      if (!requiredText(form, values, ["name", "city"])) break;
      data.profiles[v.role] = { name: values.name, city: values.city, bio: values.bio };
      v.page = "profile";
      v.drafts = {};
      persist(id, "A profilodat frissítetted.", { top: true, pageFocus: true });
      break;
    case "chat":
      if (job) sendChat(id, v, job, form, values.message);
      break;
    case "review": {
      const hasReview = data.reviews.some(review => review.jobId === job?.id && review.from === v.role);
      if (!job || job.status !== "completed" || hasReview) {
        goBack(id);
        break;
      }
      if (!requiredText(form, values, ["text"])) break;
      data.reviews.unshift({ jobId: job.id, from: v.role, to: otherRole[v.role], rating: Number(values.rating), text: values.text });
      notify(otherRole[v.role], "review", "Új értékelést kaptál", job.title, job.id);
      delete v.drafts[draftKey(v, "review")];
      v.page = "detail";
      persist(id, "Elküldted az értékelést.", { top: true, pageFocus: true });
      break;
    }
  }
});

const desktop = document.querySelector("#bongeszo");
function updateSectionNav() {
  const current = desktop.getBoundingClientRect().top <= 200 ? "bongeszo" : "mobil";
  document.querySelectorAll("[data-section-link]").forEach(link => {
    if (link.dataset.sectionLink === current) link.setAttribute("aria-current", "location");
    else link.removeAttribute("aria-current");
  });
}

window.addEventListener("scroll", updateSectionNav, { passive: true });
window.addEventListener("resize", updateSectionNav);
hydrateIcons(document);
renderAll();
updateSectionNav();
